﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations.Schema;

namespace BuildingStore.Models
{
    public class Product
    {
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Пожалуйста введите наименование товара")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Пожалуйста укажите категорию ")]
        public string Category { get; set; }

        [Required(ErrorMessage = "Пожалуйста введите положительное значение")]
        [Range(0, int.MaxValue)]
        public int Count { get; set; }

        [Required(ErrorMessage = "Пожалуйста введите положительное значение")]
        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }

       // [NotMapped]
       // public virtual ICollection<Order> Orders { get; set; }

       


    }
}
